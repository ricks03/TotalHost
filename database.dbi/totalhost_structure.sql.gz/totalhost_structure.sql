/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: totalhost
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `GameUsers`
--

DROP TABLE IF EXISTS `GameUsers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GameUsers` (
  `GameName` varchar(50) DEFAULT NULL,
  `GameFile` varchar(50) NOT NULL,
  `User_Login` varchar(50) NOT NULL,
  `RaceFile` varchar(50) DEFAULT NULL,
  `RaceID` int(11) DEFAULT 0,
  `DelaysLeft` tinyint(3) unsigned DEFAULT 0,
  `PlayerID` int(11) NOT NULL DEFAULT 0,
  `PlayerStatus` int(11) DEFAULT 0,
  `JoinDate` int(11) DEFAULT 0,
  `LastSubmitted` int(11) DEFAULT 0,
  PRIMARY KEY (`GameFile`,`User_Login`,`PlayerID`),
  KEY `GameName` (`GameName`),
  KEY `PlayerID` (`PlayerID`),
  KEY `RaceID` (`RaceID`),
  KEY `User_Login` (`User_Login`)
) ENGINE=Aria DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Games`
--

DROP TABLE IF EXISTS `Games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Games` (
  `GameName` varchar(31) NOT NULL,
  `GameFile` varchar(8) NOT NULL,
  `GameDescrip` varchar(50) DEFAULT NULL,
  `HostName` varchar(25) DEFAULT NULL,
  `GameType` int(11) DEFAULT 0,
  `DailyTime` varchar(50) DEFAULT NULL,
  `HourlyTime` varchar(24) DEFAULT NULL,
  `LastTurn` int(11) DEFAULT 0,
  `NextTurn` int(11) DEFAULT 0,
  `GameStatus` tinyint(3) unsigned DEFAULT 0,
  `DelayCount` tinyint(3) unsigned DEFAULT 0,
  `AsAvailable` tinyint(1) DEFAULT NULL,
  `OnlyIfAvailable` tinyint(1) DEFAULT NULL,
  `DayFreq` varchar(7) DEFAULT NULL,
  `HourFreq` varchar(24) DEFAULT NULL,
  `ForceGen` tinyint(1) DEFAULT NULL,
  `ForceGenTurns` tinyint(3) unsigned DEFAULT 0,
  `ForceGenTimes` tinyint(3) unsigned DEFAULT 0,
  `HostMod` tinyint(1) DEFAULT NULL,
  `HostForce` tinyint(1) DEFAULT NULL,
  `NoDuplicates` tinyint(1) DEFAULT NULL,
  `GameRestore` tinyint(1) DEFAULT NULL,
  `AnonPlayer` tinyint(1) DEFAULT NULL,
  `GamePause` tinyint(1) DEFAULT NULL,
  `GameDelay` tinyint(1) DEFAULT NULL,
  `NumDelay` int(11) DEFAULT 0,
  `MinDelay` int(11) DEFAULT 0,
  `AutoInactive` int(11) DEFAULT 0,
  `ObserveHoliday` tinyint(1) DEFAULT NULL,
  `NewsPaper` tinyint(1) DEFAULT NULL,
  `SharedM` tinyint(1) DEFAULT NULL,
  `Notes` longtext DEFAULT NULL,
  `MaxPlayers` tinyint(3) unsigned DEFAULT 16,
  `HostAccess` tinyint(1) DEFAULT NULL,
  `PublicMessages` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`GameFile`),
  UNIQUE KEY `GameName` (`GameName`)
) ENGINE=Aria DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Races`
--

DROP TABLE IF EXISTS `Races`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Races` (
  `RaceID` int(11) NOT NULL AUTO_INCREMENT,
  `RaceFile` varchar(50) NOT NULL,
  `RaceName` varchar(50) NOT NULL,
  `User_Login` varchar(50) DEFAULT NULL,
  `RaceDescrip` varchar(50) DEFAULT NULL,
  `User_File` varchar(8) DEFAULT NULL,
  UNIQUE KEY `RaceID` (`RaceID`)
) ENGINE=Aria AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `User_ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_Login` varchar(25) NOT NULL,
  `User_File` varchar(8) DEFAULT NULL,
  `User_First` varchar(50) DEFAULT NULL,
  `User_Last` varchar(50) DEFAULT NULL,
  `User_Password` varchar(50) DEFAULT NULL,
  `User_Bio` varchar(255) DEFAULT NULL,
  `Comments` varchar(50) DEFAULT NULL,
  `CreateGame` tinyint(1) DEFAULT NULL,
  `User_Email` varchar(50) NOT NULL,
  `EmailTurn` tinyint(1) DEFAULT NULL,
  `EmailList` tinyint(1) DEFAULT NULL,
  `User_Status` int(11) DEFAULT 0,
  `User_Creation` varchar(50) DEFAULT NULL,
  `User_Modified` varchar(50) DEFAULT NULL,
  `User_Serial` varchar(50) DEFAULT NULL,
  `User_Timezone` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`User_Login`),
  UNIQUE KEY `User_Email` (`User_Email`),
  KEY `User_ID` (`User_ID`),
  KEY `User_Login` (`User_Login`)
) ENGINE=Aria AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_GameStatus`
--

DROP TABLE IF EXISTS `_GameStatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_GameStatus` (
  `GameStatus` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `GameStatus_TXT` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`GameStatus`)
) ENGINE=Aria DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_GameType`
--

DROP TABLE IF EXISTS `_GameType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_GameType` (
  `GameType` int(11) NOT NULL DEFAULT 0,
  `GameType_txt` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`GameType`)
) ENGINE=Aria DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_Holidays`
--

DROP TABLE IF EXISTS `_Holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_Holidays` (
  `Holiday` datetime DEFAULT NULL,
  `Holiday_txt` varchar(50) DEFAULT NULL,
  `Nationality` varchar(2) DEFAULT NULL
) ENGINE=Aria DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_PlayerStatus`
--

DROP TABLE IF EXISTS `_PlayerStatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_PlayerStatus` (
  `PlayerStatus` int(11) NOT NULL DEFAULT 0,
  `PlayerStatus_txt` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`PlayerStatus`)
) ENGINE=Aria DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_UserStatus`
--

DROP TABLE IF EXISTS `_UserStatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_UserStatus` (
  `User_Status` int(11) DEFAULT 0,
  `User_Status_txt` varchar(50) DEFAULT NULL,
  `User_Status_Detail` varchar(50) DEFAULT NULL
) ENGINE=Aria DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_UserStatus_old`
--

DROP TABLE IF EXISTS `_UserStatus_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_UserStatus_old` (
  `Status` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `Status_txt` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Status`)
) ENGINE=Aria DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_Version`
--

DROP TABLE IF EXISTS `_Version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_Version` (
  `Version` varchar(50) NOT NULL,
  PRIMARY KEY (`Version`)
) ENGINE=Aria DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci PAGE_CHECKSUM=1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-04 21:56:35
